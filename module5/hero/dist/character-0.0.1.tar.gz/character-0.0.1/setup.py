# -----------------------------
#                             |
#    github.com/nudimannui4e  |
#                             |
# -----------------------------

from setuptools import setup

setup(
    name='character',
    version='0.0.1',
    description='Первые попытки создать class, и прописать ему методы',
    author='nudimannui4e',
    author_email='nudimannui4e@protonmail.com',
    url='https://nudimannui4e.github.io/',
    py_modules=['character.py'],
    license='OpenSource'
)